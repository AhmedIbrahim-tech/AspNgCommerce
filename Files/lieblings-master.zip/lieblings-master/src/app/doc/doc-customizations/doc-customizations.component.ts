import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'll-doc-customizations',
  templateUrl: './doc-customizations.component.html',
  styleUrls: ['./doc-customizations.component.scss']
})
export class DocCustomizationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
