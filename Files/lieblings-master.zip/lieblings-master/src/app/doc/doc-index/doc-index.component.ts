import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'll-doc-index',
  templateUrl: './doc-index.component.html',
  styleUrls: ['./doc-index.component.scss']
})
export class DocIndexComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
