export class productsDB {
    static Product = [
        {
            id: 1,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/02-1.png', 'assets/images/products/02-2.png', 'assets/images/products/02-3.png'],
            name: 'Industry marketing by subscription',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 2,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/01-1.png', 'assets/images/products/01-2.png', 'assets/images/products/01-3.png'],
            name: 'Potential analysis - digitization for manufacturing companies',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 3,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/01-1.png', 'assets/images/products/01-2.png', 'assets/images/products/01-3.png'],
            name: 'Task Management Scheduler',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 4,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/02-1.png', 'assets/images/products/02-2.png', 'assets/images/products/02-3.png'],
            name: 'Industry marketing by subscription',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 5,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/01-1.png', 'assets/images/products/01-2.png', 'assets/images/products/01-3.png'],
            name: 'Potential analysis - digitization for manufacturing companies',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 6,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/02-1.png', 'assets/images/products/02-2.png', 'assets/images/products/02-3.png'],
            name: 'Industry marketing by subscription',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 7,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/01-1.png', 'assets/images/products/01-2.png', 'assets/images/products/01-3.png'],
            name: 'Potential analysis - digitization for manufacturing companies',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 8,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/02-1.png', 'assets/images/products/02-2.png', 'assets/images/products/02-3.png'],
            name: 'Industry marketing by subscription',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
        {
            id: 9,
            created_by: {
                name: 'Sajal Mia',
                avatar: 'assets/images/avatar.png'
            },
            images: ['assets/images/products/01-1.png', 'assets/images/products/01-2.png', 'assets/images/products/01-3.png'],
            name: 'Potential analysis - digitization for manufacturing companies',
            price: 3000.00,
            rating: 4.8,
            feedback: 3,
            category: 'digitalization',
            tags: [
                'Diesel',
                'Hudson',
                'Lee'
            ],
        },
    ]
}
