import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'll-doc-components',
  templateUrl: './doc-components.component.html',
  styleUrls: ['./doc-components.component.scss']
})
export class DocComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
