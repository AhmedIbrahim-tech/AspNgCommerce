import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'll-doc-credits',
  templateUrl: './doc-credits.component.html',
  styleUrls: ['./doc-credits.component.scss']
})
export class DocCreditsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
